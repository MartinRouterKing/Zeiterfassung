function save_limit(){
    console.log("HELLO");
    var x = $('#id_users option:selected').text();
    var cat_choice = $('#id_users');
    console.log(x);
    console.log(cat_choice);
};