$('#cat_select').selectpicker();
$('#wie_select').selectpicker();
$('#obj_select').selectpicker();
$('#id_user').selectpicker();
