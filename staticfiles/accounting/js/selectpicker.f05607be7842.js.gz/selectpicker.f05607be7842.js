$('#cat_select').selectpicker();
$('#wie_select').selectpicker();
$('#obj_select').selectpicker();
$('#user_select').selectpicker();
